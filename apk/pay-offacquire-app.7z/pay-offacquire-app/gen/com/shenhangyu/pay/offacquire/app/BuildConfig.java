/** Automatically generated file. DO NOT MODIFY */
package com.shenhangyu.pay.offacquire.app;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}