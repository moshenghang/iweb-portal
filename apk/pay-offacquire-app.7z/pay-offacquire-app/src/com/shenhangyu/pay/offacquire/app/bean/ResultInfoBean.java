package com.shenhangyu.pay.offacquire.app.bean;

public class ResultInfoBean {
	private String resultCod;
	private String resultMsg;
	public String getResultCod() {
		return resultCod;
	}
	public void setResultCod(String resultCod) {
		this.resultCod = resultCod;
	}
	public String getResultMsg() {
		return resultMsg;
	}
	public void setResultMsg(String resultMsg) {
		this.resultMsg = resultMsg;
	}
	@Override
	public String toString() {
		return "ResultInfoBean [resultCod=" + resultCod + ", resultMsg="
				+ resultMsg + "]";
	}
	
}
