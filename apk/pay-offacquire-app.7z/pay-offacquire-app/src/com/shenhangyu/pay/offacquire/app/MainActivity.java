package com.shenhangyu.pay.offacquire.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {
	private static String tag = "MAIN";
	private static String session = "";
	private static Button main_pay_btn,main_clock_btn,main_setting_btn,main_calculator_btn,main_update_btn;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		main_pay_btn = (Button)findViewById(R.id.main_pay_btn_id);
		main_pay_btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				Log.i(tag,"点击了收银按钮,准备跳转到收银页面...........");
				//获取收银按钮的ID
				if(null == session || "".equals(session)){
					Intent intent = new Intent(MainActivity.this,LoginActivity.class);
					startActivity(intent);
				}else{
					Intent intent = new Intent(MainActivity.this,PayActivity.class);
					startActivity(intent);
				}
			}
		});
		main_setting_btn = (Button)findViewById(R.id.main_setting_btn_id);
		main_setting_btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				Log.i(tag,"点击了设置按钮,准备跳转到设置页面...........");
				//获取设置按钮的ID
				Intent intent = new Intent(MainActivity.this,SettingActivity.class);
				startActivity(intent);
			}
		});
		main_clock_btn = (Button)findViewById(R.id.main_clock_btn_id);
		main_clock_btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				Log.i(tag,"点击了时钟按钮,准备跳转到时钟页面...........");
				//获取时钟按钮的ID
				Intent intent = new Intent(MainActivity.this,ClockActivity.class);
				startActivity(intent);
			}
		});
		main_calculator_btn = (Button)findViewById(R.id.main_calculator_btn_id);
		main_calculator_btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				Log.i(tag,"点击了计算器按钮,准备跳转到计算器页面...........");
				//获取计算器按钮的ID
				Intent intent = new Intent(MainActivity.this,CalculatorActivity.class);
				startActivity(intent);
			}
		});
		main_update_btn = (Button)findViewById(R.id.main_update_btn_id);
		main_update_btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				Log.i(tag,"点击了升级按钮,准备跳转到升级页面...........");
				//获取升级按钮的ID
				Intent intent = new Intent(MainActivity.this,UpdateActivity.class);
				startActivity(intent);
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		return super.onOptionsItemSelected(item);
	}
}
