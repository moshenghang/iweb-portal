package com.shenhangyu.pay.offacquire.app;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.HttpVersion;
import org.apache.http.NameValuePair;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.params.ConnManagerParams;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

import com.shenhangyu.pay.offacquire.app.bean.LoginReqInfoBean;
import com.shenhangyu.pay.offacquire.app.bean.ResultInfoBean;
import com.shenhangyu.pay.offacquire.app.utils.HttpClientUtils;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends Activity {
	private static String tag = "LOGIN";
	private static String questHead = "http://";
	private String login_ip = "127.0.0.1";
	private static String path = ":9010/iweb-portal/check/postLogin";
	private EditText loging_ip_e,loging_account_e,loging_password_e;
	private Button login_reset_btn,login_in_btn;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
//		requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
		setContentView(R.layout.activity_login);
//		getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE,R.layout.titlebar);
		loging_ip_e = (EditText)findViewById(R.id.loging_ip_e_id);
		loging_account_e = (EditText)findViewById(R.id.loging_account_e_id);
		loging_password_e = (EditText)findViewById(R.id.loging_password_e_id);
		login_reset_btn = (Button)findViewById(R.id.login_reset_btn_id);
		login_reset_btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				Log.i(tag,"点击了重置按钮,清空输入内容...........");
				//获取输入控件的ID
				loging_password_e.setText("");
				loging_account_e.setText("");
			}
		});
		
		//获取登录控件ID
		login_in_btn = (Button)findViewById(R.id.login_in_btn_id);
		login_in_btn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Log.i(tag,"点击了登录按钮,准备校验账号密码...........");
				login_ip = loging_ip_e.getText().toString();
				String urlPath = questHead+login_ip+path;
				Log.i(tag,"请求地址是："+urlPath);
				String loginAccount = loging_account_e.getText().toString();
				String loginPassword = loging_password_e.getText().toString();
				Log.i(tag,"输入的信息:"+loginAccount+","+loginPassword);
				// TODO Auto-generated method stub
				LoginReqInfoBean loginReqInfoBean = new LoginReqInfoBean();
				loginReqInfoBean.setLoginAccount(loginAccount);
				loginReqInfoBean.setLoginPassword(loginPassword);
				HttpClientUtils hcUtils = new HttpClientUtils();
				ResultInfoBean resultInfoBean = null;
				try {
					resultInfoBean = hcUtils.sendDataWithPost(urlPath, loginReqInfoBean);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(null == resultInfoBean){
					Toast.makeText(getApplicationContext(), "后台服务异常!", Toast.LENGTH_SHORT).show();
				}else{
					String resultCod = resultInfoBean.getResultCod();
					String resultMsg = resultInfoBean.getResultMsg();
					if("200".equals(resultCod)){
						Toast.makeText(getApplicationContext(), resultMsg, Toast.LENGTH_SHORT).show();
						Intent intent = new Intent(LoginActivity.this,PayActivity.class);
						startActivity(intent);
					}else{
						Toast.makeText(getApplicationContext(), resultMsg, Toast.LENGTH_SHORT).show();
					}
				}
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.top_menu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_top_menu_id) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
