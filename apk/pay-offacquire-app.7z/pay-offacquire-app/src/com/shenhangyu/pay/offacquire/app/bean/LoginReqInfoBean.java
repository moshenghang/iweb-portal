package com.shenhangyu.pay.offacquire.app.bean;

public class LoginReqInfoBean {
	private String loginAccount;
	private String loginPassword;
	public String getLoginAccount() {
		return loginAccount;
	}
	public void setLoginAccount(String loginAccount) {
		this.loginAccount = loginAccount;
	}
	public String getLoginPassword() {
		return loginPassword;
	}
	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}
	@Override
	public String toString() {
		return "LoginReqInfoBean [loginAccount=" + loginAccount
				+ ", loginPassword=" + loginPassword + "]";
	}
}
