package com.shenhangyu.pay.offacquire.app.utils;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.HttpVersion;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.params.ConnManagerParams;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

import android.util.Log;

import com.shenhangyu.pay.offacquire.app.bean.LoginReqInfoBean;
import com.shenhangyu.pay.offacquire.app.bean.ResultInfoBean;

public class HttpClientUtils {
	private String tag = "HTTPCLIENTUTILS";
	public ResultInfoBean sendDataWithPost(String urlPath,LoginReqInfoBean loginReqInfoBean) throws Exception{
		ResultInfoBean resultInfoBean = new ResultInfoBean();
		resultInfoBean.setResultCod("888");
		resultInfoBean.setResultMsg("服务异常");
		if(null == urlPath || null == loginReqInfoBean){
			resultInfoBean.setResultCod("300");
			resultInfoBean.setResultMsg("请求对象不能为空");
			return resultInfoBean;
		}
		Log.i(tag,"请求API："+urlPath+","+loginReqInfoBean.toString());
		String loginAccount = loginReqInfoBean.getLoginAccount();
		String loginPassword = loginReqInfoBean.getLoginPassword();
		if(null == loginAccount || null == loginPassword){
			resultInfoBean.setResultCod("301");
			resultInfoBean.setResultMsg("登录账号密码不能为空");
			return resultInfoBean;
		}
		HttpParams params = new BasicHttpParams();
		HttpProtocolParams.setContentCharset(params, "UTF-8");
		HttpProtocolParams.setVersion(params,HttpVersion.HTTP_1_1);
		ConnManagerParams.setTimeout(params, 1000);
		HttpConnectionParams.setConnectionTimeout(params, 5000);
		HttpConnectionParams.setSoTimeout(params, 5000);
		SchemeRegistry schReg = new SchemeRegistry();
		schReg.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
		schReg.register(new Scheme("https", SSLSocketFactory.getSocketFactory(), 443));
		ClientConnectionManager conman = new ThreadSafeClientConnManager(params, schReg);
		HttpClient client = new DefaultHttpClient(conman, params);
		HttpPost post = new HttpPost(urlPath);
		JSONObject jsonObj = new JSONObject();
		try {
			jsonObj.put("loginAccount", loginAccount);
			jsonObj.put("loginPassword", loginPassword);
			NameValuePair info = new BasicNameValuePair("login", jsonObj.toString());
			List<NameValuePair> parameters = new ArrayList<NameValuePair>();
			parameters.add(info);
			post.setEntity(new UrlEncodedFormEntity(parameters, "UTF-8"));
			HttpResponse response = client.execute(post);
			if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK){
				HttpEntity entity = response.getEntity();
				String responseStr = EntityUtils.toString(entity, "UTF-8");
				JSONObject responseJsonObj = new JSONObject(responseStr);
				boolean result = responseJsonObj.getBoolean("json");
				if(result){
					resultInfoBean.setResultCod("200");
					resultInfoBean.setResultMsg("登录校验成功");
				}else{
					resultInfoBean.setResultCod("201");
					resultInfoBean.setResultMsg("登录密码错误");
				}
				client.getConnectionManager().shutdown();
			}
		} catch (Exception e) {
			// TODO: handle exception
			Log.e(tag,"连接服务异常！");
			throw new Exception();
		}
		return resultInfoBean;
	}
}
